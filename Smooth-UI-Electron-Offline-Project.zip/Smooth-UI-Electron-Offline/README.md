# Smooth UI 2.0 — Offline Windows Edition

Build: `npm install` then `npm run dist`
Run: `npm start`

Tailwind CSS and Lucide are packaged locally, so the runtime UI does not load them from CDNs.

Native telemetry is collected locally through Electron/systeminformation for CPU, RAM, GPU utilization when exposed by the Windows driver, disk, network traffic, and battery. No telemetry is uploaded.

GPU utilization can be unavailable on some drivers; the app does not fabricate a reading.
